import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { TestInterceptor } from './interceptors/test/test.interceptor';

@Controller()
export class AppController {
  @Get('all')
  @UseInterceptors(TestInterceptor)
  getAll() {
    return 'Interceptor executed';
  }
}

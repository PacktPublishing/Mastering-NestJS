import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { ResponseTransformInterceptor } from './interceptors/response-transform/response-transform.interceptor';

@Controller()
export class AppController {
  @Get('get')
  @UseInterceptors(ResponseTransformInterceptor)
  getData() {
    return {
      message: 'This is the response data',
    };
  }
}

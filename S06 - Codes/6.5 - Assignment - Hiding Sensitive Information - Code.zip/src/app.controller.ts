import { Controller, Get, Param, UseInterceptors } from '@nestjs/common';
import { UserService } from './services/user/user.service';
import { UserDataTransformInterceptor } from './interceptors/user-data-transform/user-data-transform.interceptor';

@Controller()
export class AppController {
  constructor(private readonly userService: UserService) {}

  @Get(':id')
  @UseInterceptors(UserDataTransformInterceptor)
  getData(@Param('id') id: string) {
    return this.userService.findOne(+id);
  }
}

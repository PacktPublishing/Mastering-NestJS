import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { UserDataTransformInterceptor } from './interceptors/user-data-transform/user-data-transform.interceptor';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalInterceptors(new UserDataTransformInterceptor());
  await app.listen(3000);
}
bootstrap();

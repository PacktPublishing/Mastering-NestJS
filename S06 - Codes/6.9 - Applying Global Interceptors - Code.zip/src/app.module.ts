import { Module } from '@nestjs/common';
import { AppService } from './app.service';
import { AppController } from './app.controller';
import { UserService } from './services/user/user.service';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AuthInterceptor } from './interceptors/auth/auth.interceptor';

@Module({
  imports: [],
  controllers: [AppController],
  providers: [
    AppService,
    UserService,
    // {
    //   provide: APP_INTERCEPTOR,
    //   useClass: AuthInterceptor,
    // },
  ],
})
export class AppModule {}

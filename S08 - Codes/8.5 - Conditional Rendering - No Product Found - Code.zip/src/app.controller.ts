import { Controller, Get, Render } from '@nestjs/common';
import { products } from './products/product';

@Controller()
export class AppController {
  @Get('mystore')
  @Render('home')
  renderPage() {
    return { products };
  }
}

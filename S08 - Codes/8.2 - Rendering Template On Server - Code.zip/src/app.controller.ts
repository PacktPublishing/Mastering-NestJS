import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class AppController {
  @Get('mystore')
  @Render('home')
  renderPage() {
    return { message: 'Welcome to the Home Page' };
  }
}

export const products = [
  {
    id: 1,
    name: 'Apple',
    price: 12,
    img: 'apples.png',
  },
  {
    id: 2,
    name: 'Orange',
    price: 15,
    img: 'orange.jpg',
  },
  {
    id: 3,
    name: 'Banana',
    price: 13,
    img: 'bananas.jpg',
  },
  {
    id: 4,
    name: 'Pineapple',
    price: 16,
    img: 'pineapple.jpg',
  },
];

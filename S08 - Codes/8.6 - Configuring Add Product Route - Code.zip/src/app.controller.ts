import { Controller, Get, Render } from '@nestjs/common';
import { products } from './products/product';

@Controller('mystore')
export class AppController {
  @Get('home')
  @Render('home')
  renderPage() {
    return { products };
  }

  @Get('add-product')
  @Render('add-product')
  renderAddProductPage() {
    return null;
  }
}

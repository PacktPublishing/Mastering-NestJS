import {
  Controller,
  Get,
  Param,
  ParseBoolPipe,
  ParseIntPipe,
  Query,
} from '@nestjs/common';

@Controller()
export class AppController {
  @Get(':id')
  getId(@Param('id', ParseIntPipe) id: number) {
    return `Fetched Id: ${id}`;
  }
}

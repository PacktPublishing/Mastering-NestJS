import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { CustomPipe } from './customPipe/customPipe';

@Controller('auth')
export class AuthController {
  @Get('register/:id')
  @UsePipes(new CustomPipe())
  getId(@Param('id') id: number) {
    return {
      data: id,
    };
  }

  @Post('register')
  @UsePipes(new ValidationPipe(), new CustomPipe())
  registerUser(@Body('name') name: string) {
    return {
      data: name,
    };
  }
}

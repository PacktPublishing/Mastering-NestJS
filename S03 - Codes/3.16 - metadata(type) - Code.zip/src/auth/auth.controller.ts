import {
  Body,
  Controller,
  Post,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { CustomPipe } from './customPipe/customPipe';

@Controller('auth')
export class AuthController {
  @Post('register')
  @UsePipes(new ValidationPipe(), new CustomPipe())
  registerUser(@Body('name') name: string) {
    return {
      data: name,
    };
  }
}

import { Injectable } from '@nestjs/common';
import { UserDTO } from 'src/DTO/user.dto';
import { User } from 'src/entities/user';
import * as bcrypt from 'bcrypt';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private readonly UserModel: Model<User>,
  ) {}

  async createUser(createUserDto: UserDTO) {
    const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
    const newUser = new this.UserModel({
      ...createUserDto,
      password: hashedPassword,
    });
    return await newUser.save();
  }

  async findUserByUsername(username: string) {
    return await this.UserModel.findOne({ username }).exec();
  }

  async comparePasswords(password: string, hashedPassword: string) {
    return bcrypt.compare(password, hashedPassword);
  }
}

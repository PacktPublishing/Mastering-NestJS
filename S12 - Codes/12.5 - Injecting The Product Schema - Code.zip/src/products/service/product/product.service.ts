import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { InjectRepository } from '@nestjs/typeorm';
import { Model } from 'mongoose';
import { ProductDTO } from 'src/DTO/product.dto';
import { Product } from 'src/entities/product';
import { Repository } from 'typeorm';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel(Product.name) private readonly ProductModel: Model<Product>,
  ) {}

  async addProduct(newProduct: ProductDTO) {
    const product = new this.ProductModel(newProduct);
    return await product.save();
  }

  async getAll() {
    return await this.ProductModel.find().exec();
  }

  async getOne(id: string) {
    const product = await this.ProductModel.findById(id).exec();
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }

  async updateProduct(id: string, updateData: ProductDTO) {
    const product = await this.ProductModel.findByIdAndUpdate(id, updateData, {
      new: true,
    }).exec();
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }

  async deleteProduct(id: string) {
    const product = await this.ProductModel.findByIdAndDelete(id).exec();
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }
    return product;
  }
}

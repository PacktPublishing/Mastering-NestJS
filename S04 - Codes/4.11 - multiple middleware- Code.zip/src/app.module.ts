import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { RequestDetailsMiddleware } from './middleware/request-details/request-details.middleware';
import { TimeStampMiddleware } from './middleware/time-stamp/time-stamp.middleware';

@Module({
  imports: [],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(RequestDetailsMiddleware, TimeStampMiddleware)
      .forRoutes(AppController);
  }
}

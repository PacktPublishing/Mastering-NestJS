import { Injectable, NestMiddleware } from '@nestjs/common';

@Injectable()
export class ContentTypeMiddleware implements NestMiddleware {
  use(req: any, res: any, next: () => void) {
    const contentType = req.headers['content-type'];

    // Check if Content-Type header is present
    if (!contentType) {
      return res
        .status(400)
        .json({ message: 'Content-Type header is missing' });
    }

    // Check if Content-Type is application/json
    if (contentType !== 'application/json') {
      return res.status(415).json({
        message: 'Unsupported Media Type. Only application/json is supported',
      });
    }
    next();
  }
}

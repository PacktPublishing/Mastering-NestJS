import { Body, Controller, Get, Post } from '@nestjs/common';
import { UserService } from './services/user/user.service';
import { UserDTO } from './UserDTO/user.dto';

@Controller()
export class AppController {
  constructor(private readonly userService: UserService) {}

  @Post()
  createUser(@Body() userDto: UserDTO) {
    return `User created successfully`;
  }

  @Get()
  getAllUsers(): UserDTO[] {
    return this.userService.getAllUsers();
  }
}

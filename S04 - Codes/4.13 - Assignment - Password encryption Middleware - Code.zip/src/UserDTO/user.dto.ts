import {
  IsAlphanumeric,
  IsNotEmpty,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';

export class UserDTO {
  @IsString()
  @IsNotEmpty({ message: 'Username required' })
  @MaxLength(20, { message: 'Username cannot be longer than 20 characters' })
  readonly name: string;

  @IsString()
  @IsNotEmpty({ message: 'Password required' })
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  readonly password: string;

  readonly createdAt?: string;
}

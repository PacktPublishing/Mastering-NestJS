import { Body, Controller, Post } from '@nestjs/common';

@Controller()
export class AppController {
  @Post()
  create(@Body() body: any) {
    return body;
  }
}

import { NextFunction, Request, Response } from 'express';

export function RequestDetailsMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  const { method, url, body, headers } = req;
  const requestData = {
    method: method,
    url: url,
    body: body,
    userAgent: headers['user-agent'],
    contentType: headers['content-type'],
  };
  res.json(requestData);
}

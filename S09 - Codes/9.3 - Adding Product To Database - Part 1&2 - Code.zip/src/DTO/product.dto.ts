import { IsString } from '@nestjs/class-validator';

export class ProductDTO {
  @IsString()
  productname: string;

  price: number;

  image: string;
}

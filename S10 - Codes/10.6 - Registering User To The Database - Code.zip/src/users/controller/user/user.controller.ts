import { Body, Controller, Post, Redirect } from '@nestjs/common';
import { UserDTO } from 'src/DTO/user.dto';
import { UserService } from 'src/users/service/user/user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('sign-up')
  @Redirect('/mystore/home')
  async signUp(@Body() newUser: UserDTO) {
    return await this.userService.createUser(newUser);
  }
}

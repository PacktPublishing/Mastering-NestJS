import { User } from 'src/entities/user'; // Import your User type or any type you use for user payload

declare global {
  namespace Express {
    interface Request {
      user?: User; // Define the type for user, or use any if you don't have a specific type
    }
  }
}

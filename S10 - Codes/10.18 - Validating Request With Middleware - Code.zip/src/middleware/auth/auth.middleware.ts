import { Injectable, NestMiddleware } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request, Response } from 'express';

@Injectable()
export class AuthMiddleware implements NestMiddleware {
  constructor(private readonly jwtService: JwtService) {}

  use(req: Request, res: Response, next: () => void) {
    const token = req.session.token;

    try {
      const decodedToken = this.jwtService.verify(token);
      console.log(decodedToken);
    } catch (err) {
      return res.redirect('/user/login');
    }

    next();
  }
}

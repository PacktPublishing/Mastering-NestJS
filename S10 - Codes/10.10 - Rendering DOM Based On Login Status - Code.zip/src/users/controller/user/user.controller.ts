import {
  Body,
  Controller,
  Get,
  Post,
  Redirect,
  Render,
  Res,
} from '@nestjs/common';
import { Response } from 'express';
import { UserDTO } from 'src/DTO/user.dto';
import { UserService } from 'src/users/service/user/user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get('login')
  @Render('login')
  renderLogin() {
    return null;
  }

  @Post('sign-up')
  @Redirect('/mystore/home')
  async signUp(@Body() newUser: UserDTO) {
    return await this.userService.createUser(newUser);
  }

  @Post('login')
  async userLogin(@Body() body: UserDTO, @Res() res: Response) {
    const { username, password } = body;

    const user = await this.userService.findUserByUsername(username);

    if (user) {
      if (user.password === password) {
        res.cookie('isLoggedIn', 'true');
        return res.redirect('/mystore/home');
      } else {
        res.cookie('isLoggedIn', 'invalidPassword');
        return res.redirect('/user/login');
      }
    } else {
      res.cookie('isLoggedIn', 'invalidUsername');
      return res.redirect('/user/login');
    }
  }
}

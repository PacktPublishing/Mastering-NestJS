import { Body, Controller, Post } from '@nestjs/common';
import { ProductDTO } from 'src/dto/product.dto';
import { ProductService } from 'src/products/services/product/product.service';

@Controller('product')
export class ProductController {
  constructor(private productService: ProductService) {}

  @Post()
  async addProduct(@Body() productData: ProductDTO) {
    await this.productService.addProduct(productData);
    return 'Product added successfully';
  }
}

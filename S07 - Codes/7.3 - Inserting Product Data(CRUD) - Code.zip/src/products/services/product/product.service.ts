import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductDTO } from 'src/dto/product.dto';
import { Product } from 'src/entities/product';
import { Repository } from 'typeorm';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Product) private productRepository: Repository<Product>,
  ) {}

  async addProduct(newProduct: ProductDTO) {
    const { productname, price } = newProduct;
    const product = this.productRepository.create({
      productname,
      price,
    });
    return await this.productRepository.save(product);
  }
}

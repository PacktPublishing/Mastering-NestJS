export class ProductDTO {
  productname: string;
  price: number;
}

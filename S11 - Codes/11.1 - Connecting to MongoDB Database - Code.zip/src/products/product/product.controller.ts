import { Controller } from '@nestjs/common';

@Controller('product')
export class ProductController {}

import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Product } from '../product.schema';
import { Model } from 'mongoose';
import { ProductDTO } from '../DTO/product.dto';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel(Product.name) private productModel: Model<Product>,
  ) {}

  async create(newProduct: ProductDTO): Promise<Product> {
    const addProduct = new this.productModel(newProduct);
    return await addProduct.save();
  }

  async findAll() {
    return await this.productModel.find().exec();
  }

  async findOne(id: string) {
    return await this.productModel.findById(id).exec();
  }

  async update(id: string, productDTO: ProductDTO) {
    return await this.productModel
      .findByIdAndUpdate(id, productDTO, { new: true })
      .exec();
  }

  async delete(id: string) {
    return await this.productModel.findByIdAndDelete(id).exec();
  }
}

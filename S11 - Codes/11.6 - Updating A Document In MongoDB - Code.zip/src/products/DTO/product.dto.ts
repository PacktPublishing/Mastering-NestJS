import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class ProductDTO {
  @IsString()
  @IsNotEmpty()
  productname: string;

  @IsNumber()
  @IsNotEmpty()
  price: number;
}

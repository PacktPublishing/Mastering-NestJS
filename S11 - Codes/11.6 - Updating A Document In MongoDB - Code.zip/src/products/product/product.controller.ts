import {
  Body,
  Controller,
  Get,
  HttpException,
  Param,
  Patch,
  Post,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { ProductService } from './product.service';
import { ProductDTO } from '../DTO/product.dto';
import mongoose from 'mongoose';

@Controller('product')
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  @Post()
  @UsePipes(new ValidationPipe())
  async create(@Body() productDTO: ProductDTO) {
    await this.productService.create(productDTO);
    return 'Product added successfully';
  }

  @Get()
  async findAll() {
    return this.productService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    const isValid = mongoose.Types.ObjectId.isValid(id);
    if (!isValid) throw new HttpException('Product id is not valid', 404);
    const product = await this.productService.findOne(id);
    if (!product) throw new HttpException('Product not found', 404);
    return product;
  }

  @Patch(':id')
  @UsePipes(new ValidationPipe())
  async update(@Param('id') id: string, @Body() productDTO: ProductDTO) {
    const isValid = mongoose.Types.ObjectId.isValid(id);
    if (!isValid) throw new HttpException('Product id is not valid', 404);
    const product = await this.productService.update(id, productDTO);
    if (!product) throw new HttpException('Product not found', 404);
    return product;
  }
}

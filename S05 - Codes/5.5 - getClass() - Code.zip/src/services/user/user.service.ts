import { Injectable } from '@nestjs/common';

@Injectable()
export class UserService {
  private users: string[] = ['UserA', 'UserB', 'UserC'];

  getUsers(): string[] {
    return this.users;
  }
}

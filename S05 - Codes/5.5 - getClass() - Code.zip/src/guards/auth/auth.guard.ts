import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { AppController } from 'src/app.controller';

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const controller = context.getClass();

    if (controller !== AppController) {
      throw new UnauthorizedException(
        'This route is only accessible from the AppController',
      );
    }
    return true;
  }
}

import { Controller, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';
import { UserService } from './services/user/user.service';

@Controller('admin')
export class AppController {
  constructor(private readonly userService: UserService) {}

  @Get('users')
  @UseGuards(AuthGuard)
  getValue() {
    return this.userService.getUsers();
  }
}

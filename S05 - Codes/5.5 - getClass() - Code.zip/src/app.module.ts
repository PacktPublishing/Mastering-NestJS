import { Module } from '@nestjs/common';
import { AppService } from './app.service';
import { AppController } from './app.controller';
import { AuthGuard } from './guards/auth/auth.guard';
import { UserController } from './user/user.controller';
import { UserService } from './services/user/user.service';

@Module({
  imports: [],
  controllers: [AppController, UserController],
  providers: [AppService, AuthGuard, UserService],
})
export class AppModule {}

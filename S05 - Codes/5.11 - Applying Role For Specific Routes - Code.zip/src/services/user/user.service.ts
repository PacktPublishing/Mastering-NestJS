import { Injectable } from '@nestjs/common';
import { Role } from 'src/enum/roles.enum';

@Injectable()
export class UserService {
  private readonly users = [
    {
      apiKey: 'userA101',
      name: 'UserA',
      email: 'userA@example.com',
      roles: [Role.ADMIN],
    },
    {
      apiKey: 'userB102',
      name: 'UserB',
      email: 'userB@example.com',
      roles: [Role.USER],
    },
    {
      apiKey: 'userC103',
      name: 'UserC',
      email: 'userC@example.com',
      roles: [Role.USER],
    },
  ];

  getUser(apiKey: string) {
    return this.users.find((user) => user.apiKey === apiKey);
  }
  addUser(user: any) {
    return this.users.push(user);
  }
}

import {
  Body,
  Controller,
  Get,
  Post,
  Req,
  SetMetadata,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';
import { RoleGuard } from './guards/role/role.guard';
import { Roles } from './customDecorators/roles.decorator';
import { Role } from './enum/roles.enum';
import { UserService } from './services/user/user.service';

@UseGuards(AuthGuard, RoleGuard)
@Controller()
export class AppController {
  constructor(private readonly userService: UserService) {}

  @Get('user')
  @Roles(Role.USER)
  getUser(@Req() req: any) {
    const apiKey = req.user.apiKey;
    const user = this.userService.getUser(apiKey);
    if (user) {
      const { apiKey, ...userData } = user;
      return userData;
    }
  }
  @Post('create')
  @Roles(Role.ADMIN)
  create(@Body() userData: any) {
    this.userService.addUser(userData);
    return `User created successfully`;
  }
}

import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { UserService } from 'src/services/user/user.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly userService: UserService) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    const apiKey = req.headers?.api_key;

    const user = this.userService.getUser(apiKey);

    if (!user) {
      throw new UnauthorizedException('Invalid API key');
    }
    req.user = user;
    return true;
  }
}

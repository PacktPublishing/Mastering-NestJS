import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';

@Controller()
export class AppController {
  @Get(':id/:name')
  @UseGuards(AuthGuard)
  getValue(
    @Param('id') id: string,
    @Param('name') name: string,
    @Query() query: string,
  ) {
    return { id, name, query };
  }

  @Post('create')
  @UseGuards(AuthGuard)
  create(@Body() data: any) {
    return data;
  }
}

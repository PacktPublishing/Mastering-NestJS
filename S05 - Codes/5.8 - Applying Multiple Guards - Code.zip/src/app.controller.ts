import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';
import { RoleGuard } from './guards/role/role.guard';

@Controller()
export class AppController {
  @Get('user')
  @UseGuards(AuthGuard, RoleGuard)
  getUser(@Req() req: any) {
    const data = req.user;
    const { apiKey, ...userData } = data;
    return `${data.name} data: ${JSON.stringify(userData, null, 2)}`;
  }
}

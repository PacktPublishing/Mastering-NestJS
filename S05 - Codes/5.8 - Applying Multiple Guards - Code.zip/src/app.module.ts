import { Module } from '@nestjs/common';
import { AppService } from './app.service';
import { AppController } from './app.controller';
import { AuthGuard } from './guards/auth/auth.guard';
import { UserService } from './services/user/user.service';
import { RoleGuard } from './guards/role/role.guard';

@Module({
  imports: [],
  controllers: [AppController],
  providers: [AppService, AuthGuard, UserService, RoleGuard],
})
export class AppModule {}

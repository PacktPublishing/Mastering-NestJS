import { Controller, Get, Req, SetMetadata, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';
import { RoleGuard } from './guards/role/role.guard';

@Controller()
@UseGuards(AuthGuard)
export class AppController {
  @Get('user')
  @SetMetadata('roles', ['user'])
  @UseGuards(RoleGuard)
  getUser(@Req() req: any) {
    const data = req.user;
    const { apiKey, ...userData } = data;
    return `${data.name} data: ${JSON.stringify(userData, null, 2)}`;
  }
}

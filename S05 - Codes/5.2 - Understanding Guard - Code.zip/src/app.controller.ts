import { Body, Controller, Post, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';

@Controller()
export class AppController {
  @Post('create')
  @UseGuards(AuthGuard)
  create(@Body() data: any) {
    return data;
  }
}

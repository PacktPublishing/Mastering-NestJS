import { NestFactory, Reflector } from '@nestjs/core';
import { AppModule } from './app.module';
import { RoleGuard } from './guards/role/role.guard';
import { AuthGuard } from './guards/auth/auth.guard';
import { UserService } from './services/user/user.service';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const reflector = app.get(Reflector);
  const userService = app.get(UserService);

  app.useGlobalGuards(new RoleGuard(reflector), new AuthGuard(userService));
  await app.listen(3000);
}
bootstrap();

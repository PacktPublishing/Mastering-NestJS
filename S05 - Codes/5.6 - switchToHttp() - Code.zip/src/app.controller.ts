import { Controller, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';

@Controller()
export class AppController {
  @Get()
  @UseGuards(AuthGuard)
  getData() {
    return 'Access Granted';
  }
}

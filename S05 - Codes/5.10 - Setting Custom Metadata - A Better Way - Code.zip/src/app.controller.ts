import { Controller, Get, Req, SetMetadata, UseGuards } from '@nestjs/common';
import { AuthGuard } from './guards/auth/auth.guard';
import { RoleGuard } from './guards/role/role.guard';
import { Roles } from './customDecorators/roles.decorator';
import { Role } from './enum/roles.enum';

@Controller()
@UseGuards(AuthGuard)
export class AppController {
  @Get('user')
  @Roles(Role.USER)
  @UseGuards(RoleGuard)
  getUser(@Req() req: any) {
    const data = req.user;
    const { apiKey, ...userData } = data;
    return `${data.name} data: ${JSON.stringify(userData, null, 2)}`;
  }
}

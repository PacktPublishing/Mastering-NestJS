import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.getArgByIndex(0);
    const response = context.getArgByIndex(1);

    console.log('Request Params: ', request.params);
    console.log('Response Status Code: ', response.statusCode);
    return true;
  }
}
